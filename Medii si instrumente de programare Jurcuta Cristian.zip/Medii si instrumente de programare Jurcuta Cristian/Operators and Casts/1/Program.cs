﻿using System;

class Rational
{
    private int numerator;
    private int denominator;

    public Rational(int numerator, int denominator)
    {
        if (denominator == 0)
        {
            throw new ArgumentException("Numitor nu poate fi 0.");
        }

        this.numerator = numerator;
        this.denominator = denominator;
        Simplify();
    }

    public void Display()
    {
        Console.WriteLine($"{numerator}/{denominator}");
    }

    public override string ToString()
    {
        return $"{numerator}/{denominator}";
    }

    public static Rational operator +(Rational r1, Rational r2)
    {
        int newNumerator = r1.numerator * r2.denominator + r2.numerator * r1.denominator;
        int newDenominator = r1.denominator * r2.denominator;
        return new Rational(newNumerator, newDenominator);
    }

    public static Rational operator -(Rational r1, Rational r2)
    {
        int newNumerator = r1.numerator * r2.denominator - r2.numerator * r1.denominator;
        int newDenominator = r1.denominator * r2.denominator;
        return new Rational(newNumerator, newDenominator);
    }

    public static Rational operator *(Rational r1, Rational r2)
    {
        int newNumerator = r1.numerator * r2.numerator;
        int newDenominator = r1.denominator * r2.denominator;
        return new Rational(newNumerator, newDenominator);
    }

    public static Rational operator /(Rational r1, Rational r2)
    {
        if (r2.numerator == 0)
        {
            throw new DivideByZeroException("Nu poate fi impartit la 0.");
        }

        int newNumerator = r1.numerator * r2.denominator;
        int newDenominator = r1.denominator * r2.numerator;
        return new Rational(newNumerator, newDenominator);
    }

    public static bool operator <(Rational r1, Rational r2)
    {
        return r1.numerator * r2.denominator < r2.numerator * r1.denominator;
    }

    public static bool operator >(Rational r1, Rational r2)
    {
        return r1.numerator * r2.denominator > r2.numerator * r1.denominator;
    }

    public static bool operator <=(Rational r1, Rational r2)
    {
        return r1.numerator * r2.denominator <= r2.numerator * r1.denominator;
    }

    public static bool operator >=(Rational r1, Rational r2)
    {
        return r1.numerator * r2.denominator >= r2.numerator * r1.denominator;
    }

    public static bool operator ==(Rational r1, Rational r2)
    {
        return r1.numerator * r2.denominator == r2.numerator * r1.denominator;
    }

    public static bool operator !=(Rational r1, Rational r2)
    {
        return !(r1 == r2);
    }

    public override bool Equals(object obj)
    {
        if (obj is Rational)
        {
            return this == (Rational)obj;
        }
        return false;
    }

    public override int GetHashCode()
    {
        return numerator.GetHashCode() ^ denominator.GetHashCode();
    }

    private void Simplify()
    {
        int gcd = GCD(Math.Abs(numerator), Math.Abs(denominator));
        numerator /= gcd;
        denominator /= gcd;

        if (denominator < 0)
        {
            numerator = -numerator;
            denominator = -denominator;
        }
    }

    private int GCD(int a, int b)
    {
        while (b != 0)
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}

class Program
{
    static void Main()
    {
        Rational r1 = new Rational(1, 2);
        Rational r2 = new Rational(3, 4);

        Console.WriteLine("Numere rationale:");
        Console.WriteLine("r1: " + r1);
        Console.WriteLine("r2: " + r2);

        Console.WriteLine("\nOperatii:");
        Console.WriteLine("Adaos: " + (r1 + r2));
        Console.WriteLine("Scadere: " + (r1 - r2));
        Console.WriteLine("Inmultire: " + (r1 * r2));
        Console.WriteLine("Impartire: " + (r1 / r2));

        Console.WriteLine("\nComparatii:");
        Console.WriteLine("r1 < r2: " + (r1 < r2));
        Console.WriteLine("r1 > r2: " + (r1 > r2));
        Console.WriteLine("r1 <= r2: " + (r1 <= r2));
        Console.WriteLine("r1 >= r2: " + (r1 >= r2));
        Console.WriteLine("r1 == r2: " + (r1 == r2));
        Console.WriteLine("r1 != r2: " + (r1 != r2));
    }
}