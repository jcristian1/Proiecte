﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu un numar pozitiv: ");

        if (int.TryParse(Console.ReadLine(), out int userInput))
        {
            // verifică dacă numarul contine cifra 3
            bool result = IfNumberContains3(userInput);

            // afiseaza rezultatul
            Console.WriteLine($"Rezultat: {result}");
        }
        else
        {
            Console.WriteLine("Numere nevalide. Introdu numere valide pozitive");
        }
    }

    static bool IfNumberContains3(int number)
    {
        while (number > 0)
        {
            // obtine ultima cifra a numarului
            int cifra = number % 10;

            // verifica daca cifra este 3
            if (cifra == 3)
            {
                return true;
            }

            // elimina ultima cifra din numar
            number /= 10;
        }

        // daca nu exista nicio cifra 3, return false
        return false;
    }
}
