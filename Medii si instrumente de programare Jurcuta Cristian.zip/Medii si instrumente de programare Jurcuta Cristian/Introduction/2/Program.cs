﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<int> numbers = new List<int>();

        while (true)
        {
            Console.Write("Introdu un numar: ");
            string input = Console.ReadLine();

            // convertirea intr-un numar
            if (int.TryParse(input, out int number))
            {
                // adaugarea numarului listei
                numbers.Add(number);

                // verificarea daca numarul se termina cu 00
                if (input.EndsWith("00"))
                {
                    break;
                }
            }
            else
            {
                // eroare daca numarul este invalid
                Console.WriteLine("Invalid input. Please enter a valid number.");
            }
        }

        // afisarea numerelor pastrate
        Console.WriteLine("\nNumerele introduse sunt:");
        foreach (int num in numbers)
        {
            Console.WriteLine(num);
        }
    }
}
