﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu numarul de elemente ce vor fi stocate in array: ");
        if (int.TryParse(Console.ReadLine(), out int numberOfElements))
        {
            // creeaza doua array-uri pentru numere pare si impare
            int[] evenArray = new int[numberOfElements];
            int[] oddArray = new int[numberOfElements];

            // citeste elementele in array
            for (int i = 0; i < numberOfElements; i++)
            {
                Console.Write($"elementul - {i} : ");
                if (int.TryParse(Console.ReadLine(), out int currentElement))
                {
                    // verifica daca elementul este par sau impar si il adauga in array-ul corespunzator
                    if (currentElement % 2 == 0)
                    {
                        evenArray[i] = currentElement;
                    }
                    else
                    {
                        oddArray[i] = currentElement;
                    }
                }
                else
                {
                    // Afiseaza un mesaj de eroare pentru valoarea invalida
                    Console.WriteLine($"Eroare: Numar nevalid {i}. Introdu un numar valid.");
                    return;
                }
            }

            Console.WriteLine("Numerele pare sunt:");
            DisplayArray(evenArray);

            Console.WriteLine("Numere impare sunt:");
            DisplayArray(oddArray);
        }
        else
        {
            Console.WriteLine("Eroare: Numar nevalid de elemente. Introdu un numar valid.");
        }
    }

    static void DisplayArray(int[] array)
    {
        // afiseaza elementele ne-nule din tablou
        foreach (int element in array)
        {
            if (element != 0)
            {
                Console.Write(element + " ");
            }
        }
        Console.WriteLine();
    }
}
