﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu marimea matricei (mai mica de 5): ");
        if (int.TryParse(Console.ReadLine(), out int matrixSize) && matrixSize < 5)
        {
            // creeaza doua matrici de dimensiunea specificată
            int[,] firstMatrix = new int[matrixSize, matrixSize];
            int[,] secondMatrix = new int[matrixSize, matrixSize];
            int[,] sumMatrix = new int[matrixSize, matrixSize];

            Console.WriteLine("Introdu elementele primei matrici:");
            ReadMatrixElements(firstMatrix);

            Console.WriteLine("Introdu elementele a celei de-a doua matrici:");
            ReadMatrixElements(secondMatrix);

            // calculeaza suma celor doua matrici
            AddMatrices(firstMatrix, secondMatrix, sumMatrix);

            Console.WriteLine("Prima matrice este:");
            DisplayMatrix(firstMatrix);

            Console.WriteLine("A doua matrice este:");
            DisplayMatrix(secondMatrix);

            Console.WriteLine("Adunare a celor doua matrici este: ");
            DisplayMatrix(sumMatrix);
        }
        else
        {
            Console.WriteLine("Eroare: Numar nevalid pentru marimea matricii. Introdu un numar mai mic de 5.");
        }
    }

    static void ReadMatrixElements(int[,] matrix)
    {
        // citeste elementele matricii
        for (int i = 0; i < matrix.GetLength(0); i++)
        {
            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                Console.Write($"element - [{i}],[{j}] : ");
                if (int.TryParse(Console.ReadLine(), out matrix[i, j]))
                {
                }
                else
                {
                    // eroare in citire
                    Console.WriteLine($"Eroare: Numar nevalid pentru [{i}],[{j}]. Te rog introdu un numar valid.");
                    return;
                }
            }
        }
    }

    static void AddMatrices(int[,] firstMatrix, int[,] secondMatrix, int[,] sumMatrix)
    {
        // calculeaza suma celor doua matrici
        for (int i = 0; i < firstMatrix.GetLength(0); i++)
        {
            for (int j = 0; j < firstMatrix.GetLength(1); j++)
            {
                sumMatrix[i, j] = firstMatrix[i, j] + secondMatrix[i, j];
            }
        }
    }

    static void DisplayMatrix(int[,] matrix)
    {
        // afiseaza matricea
        for (int i = 0; i < matrix.GetLength(0); i++)
        {
            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                Console.Write(matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
}
