﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        Console.Write("Introdu un sir: ");
        string inputString = Console.ReadLine();

        bool result = AlmostOnlyLetters(inputString);
        Console.WriteLine($"Rezultatul este: {result}");
    }

    static bool AlmostOnlyLetters(string inputString)
    {
        if (!string.IsNullOrEmpty(inputString))
        {
            string pattern = @"^[a-zA-Z ]+\.$";
            return Regex.IsMatch(inputString, pattern);
        }

        return false;
    }
}
