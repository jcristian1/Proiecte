﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu primul sir: ");
        string firstString = Console.ReadLine();

        Console.Write("Introdu al doilea sir: ");
        string secondString = Console.ReadLine();

        string result = MixTwoStrings(firstString, secondString);
        Console.WriteLine($"Sirul combinat: {result}");
    }

    static string MixTwoStrings(string firstString, string secondString)
    {
        string result = "";

        int maxLength = Math.Max(firstString.Length, secondString.Length);

        for (int i = 0; i < maxLength; i++)
        {
            if (i < firstString.Length)
            {
                result += firstString[i];
            }

            if (i < secondString.Length)
            {
                result += secondString[i];
            }
        }

        return result;
    }
}
