﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu valoarea lui a (minim 1): ");
        string inputA = Console.ReadLine();

        Console.Write("Introdu valoarea lui b: ");
        string inputB = Console.ReadLine();

        if (double.TryParse(inputA, out double a) && double.TryParse(inputB, out double b))
        {
            // verificarea ca a sa nu fie egal cu 0
            if (a != 0)
            {
                // rezolvarea ecuatiei
                double x = -b / a;

                Console.WriteLine($"Solutia pentru ecuatia {a}x + {b} = 0 is x = {x}");
            }
            else
            {
                Console.WriteLine("Eroare: 'a' nu trebuie sa fie egal cu 0.");
            }
        }
        else
        {
            Console.WriteLine("Numere nevalide. Introdu un numar valid.");
        }
    }
}
