﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu distanta in metri: ");
        string inputDistance = Console.ReadLine();

        Console.Write("Introdu timpul in ore: ");
        string inputHours = Console.ReadLine();

        Console.Write("Introdu timpul in minute: ");
        string inputMinutes = Console.ReadLine();

        Console.Write("Introdu timpul in secunde: ");
        string inputSeconds = Console.ReadLine();

        // Converteste sirurile introduse in numere
        if (double.TryParse(inputDistance, out double distance) &&
            double.TryParse(inputHours, out double hours) &&
            double.TryParse(inputMinutes, out double minutes) &&
            double.TryParse(inputSeconds, out double seconds))
        {
            // Calculeaza viteza in metri pe secunda
            double speedMetresPerSec = distance / (hours * 3600 + minutes * 60 + seconds);

            // Converteste viteza in kilometri pe ora
            double speedKmPerHour = speedMetresPerSec * 3.6;

            // Converteste viteza in mile pe ora
            double speedMilesPerHour = speedMetresPerSec * 2.23694;

            Console.WriteLine($"Viteza ta in metri/sec este: {speedMetresPerSec}");
            Console.WriteLine($"Viteza ta in km/h este: {speedKmPerHour}");
            Console.WriteLine($"Viteza ta in mile/h este: {speedMilesPerHour}");
        }
        else
        {
            // numere nevalide
            Console.WriteLine("Numere nevalide. Introdu numere valide.");
        }
    }
}
