﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        int a = 2, b = 3;
        Console.WriteLine($"Before swap: a={a}; b={b}");
        Swap(ref a, ref b);
        Console.WriteLine($"After swap: a={a}; b={b}");

        string strA = "abc", strB = "def";
        Console.WriteLine($"Before swap: a={strA}; b={strB}");
        Swap(ref strA, ref strB);
        Console.WriteLine($"After swap: a={strA}; b={strB}");

        List<Employee> employees = new List<Employee>();

        employees.Add(new Employee(1, "John", "Doe", 30));
        employees.Add(new Employee(2, "Jane", "Smith", 25));
        employees.Add(new Employee(3, "Bob", "Johnson", 35));

        Console.WriteLine("\nList of Employees:");
        DisplayEmployees(employees);

        Console.WriteLine("\nRemoving employee with EmployeeId=2");
        RemoveEmployee(employees, 2);

        Console.WriteLine("\nList of Employees after removal:");
        DisplayEmployees(employees);
    }

    static void Swap<T>(ref T a, ref T b)
    {
        T temp = a;
        a = b;
        b = temp;
    }

    class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeFirstName { get; set; }
        public string EmployeeLastName { get; set; }
        public int EmployeeAge { get; set; }

        public Employee(int id, string firstName, string lastName, int age)
        {
            EmployeeId = id;
            EmployeeFirstName = firstName;
            EmployeeLastName = lastName;
            EmployeeAge = age;
        }

        public override string ToString()
        {
            return $"EmployeeId: {EmployeeId}, Name: {EmployeeFirstName} {EmployeeLastName}, Age: {EmployeeAge}";
        }
    }

    static void DisplayEmployees(List<Employee> employees)
    {
        foreach (Employee employee in employees)
        {
            Console.WriteLine(employee);
        }
    }

    static void RemoveEmployee(List<Employee> employees, int employeeId)
    {
        Employee employeeToRemove = employees.Find(e => e.EmployeeId == employeeId);
        if (employeeToRemove != null)
        {
            employees.Remove(employeeToRemove);
            Console.WriteLine($"Employee with EmployeeId={employeeId} removed successfully.");
        }
        else
        {
            Console.WriteLine($"Employee with EmployeeId={employeeId} not found.");
        }
    }
}
