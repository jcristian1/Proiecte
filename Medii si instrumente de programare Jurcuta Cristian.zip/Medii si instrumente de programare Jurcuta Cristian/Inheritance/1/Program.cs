﻿using System;

class Person
{
    public string Name { get; }

    public Person(string name)
    {
        Name = name;
    }

    public override string ToString()
    {
        return $"Nume: {Name}";
    }
}

class Student : Person
{
    public Student(string name) : base(name)
    {
    }

    public void Study()
    {
        Console.WriteLine($"{Name} is studying.");
    }
}

class Teacher : Person
{
    public Teacher(string name) : base(name)
    {
    }

    public void Explain()
    {
        Console.WriteLine($"{Name} is explaining.");
    }
}

class Program
{
    static void Main()
    {
        Person[] people = new Person[3];

        for (int i = 0; i < 3; i++)
        {
            Console.Write("Introdu nume: ");
            string name = Console.ReadLine();

            if (i == 0)
                people[i] = new Teacher(name);
            else
                people[i] = new Student(name);
        }

        Console.WriteLine("\nOutput:");

        foreach (Person person in people)
        {
            Console.WriteLine(person);

            if (person is Student)
                ((Student)person).Study();
            else if (person is Teacher)
                ((Teacher)person).Explain();

            Console.WriteLine();
        }
    }
}
