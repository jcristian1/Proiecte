﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu primul numar: ");
        string inputNum1 = Console.ReadLine();

        Console.Write("Introdu al doilea numar: ");
        string inputNum2 = Console.ReadLine();

        Console.Write("Introdu operația (+, -, x, /): ");
        char operatie = Console.ReadKey().KeyChar;
        Console.WriteLine();

        // converteste sirurile de intrare intr-un numar
        if (double.TryParse(inputNum1, out double num1) && double.TryParse(inputNum2, out double num2))
        {
            // realizeaza operația
            double rezultat = 0.0;
            switch (operatie)
            {
                case '+':
                    rezultat = num1 + num2;
                    break;
                case '-':
                    rezultat = num1 - num2;
                    break;
                case 'x':
                    rezultat = num1 * num2;
                    break;
                case '/':
                    // verificare pentru împartirea la zero
                    if (num2 != 0)
                    {
                        rezultat = num1 / num2;
                    }
                    else
                    {
                        Console.WriteLine("Eroare: Impartirea la zero nu este posibila.");
                        return;
                    }
                    break;
                default:
                    Console.WriteLine("Caracter neidentificat");
                    return;
            }

            Console.WriteLine($"Rezultat: {rezultat}");
        }
        else
        {
            Console.WriteLine("Numere nevalide. Introdu numere valide.");
        }
    }
}
