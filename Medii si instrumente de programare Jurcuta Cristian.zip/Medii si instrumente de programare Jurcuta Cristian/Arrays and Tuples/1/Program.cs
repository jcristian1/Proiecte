﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu numarul de elemente ce vor fi stocate în array: ");
        if (int.TryParse(Console.ReadLine(), out int numberOfElements))
        {
            // creeaza un tablou de dimensiunea specificata
            int[] array = new int[numberOfElements];

            // citeste elementele in tablou
            for (int i = 0; i < numberOfElements; i++)
            {
                Console.Write($"element - {i} : ");
                if (int.TryParse(Console.ReadLine(), out array[i]))
                {
                }
                else
                {
                    // eroare
                    Console.WriteLine($"Error: Numar nevalid pentru {i}. Introdu un numar valid.");
                    return;
                }
            }

            // suma elementelor
            int sum = CalculateSum(array);

            Console.WriteLine($"Suma tuturor elementelor stocate in array este: {sum}");
        }
        else
        {
            // eroare
            Console.WriteLine("Eroare: Input invalid pentru numărul de elemente. Introdu un numar valid.");
        }
    }

    static int CalculateSum(int[] array)
    {
        // suma elementelor
        int sum = 0;
        foreach (int element in array)
        {
            sum += element;
        }
        return sum;
    }
}