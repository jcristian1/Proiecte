USE [Bakery querying];
GO

-- Create Countries table
CREATE TABLE Countries (
    Id INT PRIMARY KEY,
    Name NVARCHAR(50) UNIQUE
);

-- Create Distributors table
CREATE TABLE Distributors (
    Id INT PRIMARY KEY IDENTITY,
    Name NVARCHAR(25) UNIQUE,
    AddressText NVARCHAR(30),
    Summary NVARCHAR(200),
    CountryId INT,
    FOREIGN KEY (CountryId) REFERENCES Countries(Id)
);

-- Create Ingredients table
CREATE TABLE Ingredients (
    Id INT PRIMARY KEY IDENTITY,
    Name NVARCHAR(30),
    Description NVARCHAR(200),
    OriginCountryId INT,
    DistributorId INT,
    FOREIGN KEY (OriginCountryId) REFERENCES Countries(Id),
    FOREIGN KEY (DistributorId) REFERENCES Distributors(Id)
);

-- Create Products table
CREATE TABLE Products (
    Id INT PRIMARY KEY IDENTITY,
    Name NVARCHAR(25) UNIQUE,
    Description NVARCHAR(250),
    Recipe NVARCHAR(MAX),
    Price DECIMAL(18, 2) CHECK (Price > 0)
);

-- Create Customers table
CREATE TABLE Customers (
    Id INT PRIMARY KEY IDENTITY,
    FirstName NVARCHAR(25),
    LastName NVARCHAR(25),
    Gender CHAR(1) CHECK (Gender IN ('M', 'F')),
    Age INT,
    PhoneNumber NVARCHAR(10),
    CountryId INT,
    FOREIGN KEY (CountryId) REFERENCES Countries(Id)
);

-- Create Feedbacks table
CREATE TABLE Feedbacks (
    Id INT PRIMARY KEY IDENTITY,
    Description NVARCHAR(255),
    Rate DECIMAL(5, 2) CHECK (Rate >= 0 AND Rate <= 10),
    ProductId INT,
    CustomerId INT,
    FOREIGN KEY (ProductId) REFERENCES Products(Id),
    FOREIGN KEY (CustomerId) REFERENCES Customers(Id)
);

-- Create ProductsIngredients table
CREATE TABLE ProductsIngredients (
    ProductId INT,
    IngredientId INT,
    PRIMARY KEY (ProductId, IngredientId),
    FOREIGN KEY (ProductId) REFERENCES Products(Id),
    FOREIGN KEY (IngredientId) REFERENCES Ingredients(Id)
);