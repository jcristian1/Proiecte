﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu un sir: ");
        string input = Console.ReadLine();

        // functiunea pentru a numara
        CountCharacters(input);
    }

    static void CountCharacters(string input)
    {
        // initializarea numaratorii
        int alphabetCount = 0;
        int digitCount = 0;
        int specialCharCount = 0;

        foreach (char ch in input)
        {
            if (char.IsLetter(ch))
            {
                // alfabet
                alphabetCount++;
            }
            else if (char.IsDigit(ch))
            {
                // cifre
                digitCount++;
            }
            else
            {
                // caractere speciale
                specialCharCount++;
            }
        }

        // Display the counts
        Console.WriteLine($"Numarul de caractere din alfabet este de: {alphabetCount}");
        Console.WriteLine($"Numarul de caractere din cifre este de: {digitCount}");
        Console.WriteLine($"Numarul de caractere speciale este de: {specialCharCount}");
    }
}