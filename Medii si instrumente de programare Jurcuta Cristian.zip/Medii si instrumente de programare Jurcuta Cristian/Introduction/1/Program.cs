﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu primul numar: ");
        string input1 = Console.ReadLine();

        Console.Write("Introdu al doilea numar: ");
        string input2 = Console.ReadLine();

        if (double.TryParse(input1, out double number1) && double.TryParse(input2, out double number2))
        {
            // calcularea sumei
            double sum = number1 + number2;

            Console.WriteLine($"Suma numerelor {number1} si {number2} este: {sum}");
        }
        else
        {
            // eroare in caz de numere nevalide
            Console.WriteLine("Numere nevalide. Introdu numere valide.");
        }
    }
}
