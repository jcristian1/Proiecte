﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu primul numar: ");
        string input1 = Console.ReadLine();

        Console.Write("Introdu al doilea numar: ");
        string input2 = Console.ReadLine();

        if (int.TryParse(input1, out int number1) && int.TryParse(input2, out int number2))
        {
            // numerele inainte de schimb
            Console.WriteLine($"Inainte de schimb: Numarul 1 = {number1}, Numarul 2 = {number2}");

            // schimbul celor 2 numere
            int temp = number1;
            number1 = number2;
            number2 = temp;

            // numerele dupa schimb
            Console.WriteLine($"DUpa schimb: Numarul 1 = {number1}, Numarul 2 = {number2}");
        }
        else
        {
            // numere nevalid
            Console.WriteLine("Numere nevalide. Introdu numere valide.");
        }
    }
}
