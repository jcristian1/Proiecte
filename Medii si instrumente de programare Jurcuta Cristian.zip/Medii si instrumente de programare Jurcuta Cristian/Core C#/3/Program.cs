﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Numărul de convertit: ");
        string inputDecimal = Console.ReadLine();

        // converteste sirul intr-un număr zecimal
        if (int.TryParse(inputDecimal, out int decimalNumber))
        {
            // reprezentarea binară
            string reprezentareBinară = ConvertToBinary(decimalNumber);

            Console.WriteLine($"Binar: {reprezentareBinară}");
        }
        else
        {
            // numere nevalide
            Console.WriteLine("Numere nevalide. Introdu numere valide.");
        }
    }

    static string ConvertToBinary(int decimalNumber)
    {
        // convertirea numărului zecimal în binar
        return Convert.ToString(decimalNumber, 2);
    }
}
