﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Introdu primul numar: ");
        if (int.TryParse(Console.ReadLine(), out int baza))
        {
            Console.Write("Introdu al doilea numar (exponent): ");
            if (int.TryParse(Console.ReadLine(), out int exponent))
            {
                // calculeaza rezultatul bazei ridicate la puterea exponentului
                int rezultat = ToPutereaLui(baza, exponent);

                Console.WriteLine($"Rezultat: {rezultat}");
            }
            else
            {
                Console.WriteLine("Numere nevalide. Introdu numere valide.");
            }
        }
        else
        {
            // afiseaza un mesaj de eroare pentru valoarea invalida
            Console.WriteLine("Numere nevalide. Introdu numere valide.");
        }
    }

    static int ToPutereaLui(int baza, int exponent)
    {
        // calculeaza baza ridicata la puterea exponent
        int rezultat = 1;

        for (int i = 0; i < exponent; i++)
        {
            rezultat *= baza;
        }

        return rezultat;
    }
}
