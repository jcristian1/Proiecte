﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        Console.Write("Introdu un sir: ");
        string inputString = Console.ReadLine();

        string result = DecimalDigitInformation(inputString);
        Console.WriteLine($"Rezultatul este: {result}");
    }

    static string DecimalDigitInformation(string inputString)
    {
        Match match = Regex.Match(inputString, @"\d");

        if (match.Success)
        {
            char digit = match.Value[0];
            int position = match.Index + 1;

            return $"Cifra {digit} la pozitia {position}";
        }

        return "Nicio cifra gasita";
    }
}
